import { Component } from '@angular/core'

@Component({

    selector: 'xor-contact-form-component',
    templateUrl: './contact.component.html',
    styleUrls: ['./contact.component.css']
})

export class ContactComponent {

}