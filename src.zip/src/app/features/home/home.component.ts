import { Component } from '@angular/core'

@Component({

    selector: 'xor-home-form-component',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css']
})

export class HomeComponent {

}