import { Component } from '@angular/core'

@Component({

    selector: 'xor-no-content',
    templateUrl: './no-content.component.html'

})

export class NoContentComponent {

}